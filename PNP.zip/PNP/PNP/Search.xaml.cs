﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PNP
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Search : Window
    {
        private DataClasses1DataContext db_con = new DataClasses1DataContext(Properties.Settings.Default.PrisonDBConnectionString);
        private string thing = "";
        public Search()
        {
            InitializeComponent();
            foreach (var s in db_con.BookStatView(false))
            {
                dabox.Items.Add(s.bookID + " " + s.bookLN + ", " + s.bookFN + " " + s.bookMN + " inserted by " + s.userID);
            }
        }



        private void Back_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }

        private void Approve_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.BookStatView(false))
            {
                if (s.bookID == thing)
                    db_con.Approve(s.bookID);
            }
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.BookStatView(false))
            {
                if (s.bookID == thing)
                    db_con.Remove(s.bookID);
            }
        }

        private void dabox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string firstword = dabox.SelectedItem.ToString();
            thing = firstword.Substring(0, firstword.IndexOf(" "));
        }

        private void All_Click(object sender, RoutedEventArgs e)
        {
            foreach (var s in db_con.BookStatView(false))
            {
                    db_con.Approve(s.bookID);
            }
        }
    }
}
