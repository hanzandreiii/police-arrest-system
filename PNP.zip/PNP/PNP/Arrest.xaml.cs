﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PNP
{
    /// <summary>
    /// Interaction logic for Arrest.xaml
    /// </summary>
    public partial class Arrest : Window
    {
        private TextBox[] boxes = new TextBox[50];
        private TextBox[] boxes2 = new TextBox[50];
        private DataClasses1DataContext db_con = new DataClasses1DataContext(Properties.Settings.Default.PrisonDBConnectionString);
        public int boxnum = 0;
        public int boxnum2 = 0;
        public string idid = "";
        private List<string> list = new List<string>();

        public Arrest()
        {
            InitializeComponent();
            boxes = new TextBox[] { Mod1, Mod2, Mod3, Mod4, Mod5, Mod6, Mod7, Mod8, Mod9 };
            boxes2 = new TextBox[] { Off1, Off2, Off3, Off4, Off5, Off6, Off7, Off8, Off9 };
            foreach (var s in db_con.tbl_Bookings)
            {
                list.Add(s.bookID.ToString().Trim() + " " + s.bookFN.ToString().Trim() + " " + s.bookLN.ToString().Trim());
            }
            names.ItemsSource = list;
        }

        private void Off1_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[0].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 0;
        }

        private void Off2_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[1].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 1;
        }

        private void Off3_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[2].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 2;
        }

        private void Off4_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[3].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 3;
        }

        private void Off5_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[4].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 4;
        }

        private void Off6_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[5].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 5;
        }

        private void Off7_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[6].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 6;
        }

        private void Off8_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[7].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 7;
        }

        private void Off9_GotFocus(object sender, RoutedEventArgs e)
        {
            boxes[boxnum].Margin = new Thickness(-651, 206, 0, 0);
            boxes[8].Margin = new Thickness(609, 206, 0, 0);
            boxnum = 8;
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            Sub.IsEnabled = true;
            if (boxnum2 == 8)
            {
                boxes2[boxnum2].Visibility = Visibility.Visible;
                Add.IsEnabled = false;
            }
            else
            {
                boxes2[boxnum2].Visibility = Visibility.Visible;
                boxnum2++;
            }

        }

        private void Sub_Click(object sender, RoutedEventArgs e)
        {
            Add.IsEnabled = true;
            if (boxnum2 == 1)
            {
                boxes2[boxnum2].Visibility = Visibility.Hidden;
                Sub.IsEnabled = false;
            }
            else
            {
                boxes2[boxnum2 - 1].Visibility = Visibility.Hidden;
                boxes2[boxnum2 - 1].Text = "";
                boxes[boxnum2 - 1].Text = "";
                boxnum2--;
            }
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            int count = 0;
            if (Location.Text.Equals("") || Arr1.Text.Equals("") || Unit.Text.Equals(""))
            {
                MessageBox.Show("Please complete the form . . .");
            }
            else
            {
                for (int x = 0; x < 9; x++)
                {
                    if (!boxes2[x].Text.Equals("") && !boxes[x].Text.Equals(""))
                    {
                        db_con.ArrestInsert(idid, boxes2[x].Text, boxes[x].Text, Location.Text, Date.Text + " " + Time.Text, Arr1.Text + " " + Arr2.Text + " " + Arr3.Text, Unit.Text);
                        db_con.LogsInsert(Variables.user, " inserted charges for ID " + idid + " on ");
                        count++;
                    }
                }
                MessageBox.Show("Succesfully inserted " + count + " charges for ID " + idid);
                new MainWindow().Show();
                this.Close();
            }
        }

        private void MainMenu_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }

        private void names_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int val = Convert.ToInt32(names.SelectedIndex);
            string choice = list.ElementAt(val);
            string firstWord = choice.Substring(0, choice.IndexOf(" "));
            idid = firstWord;
        }

        private void Location_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Location.Text == "")
            {
                LblLocation.Content = "Location Of The Arrest";
            }
            else
            {
                LblLocation.Content = "";
            }
        }

        private void Date_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Date.Text == "")
            {
                LblDate.Content = "Date Of Arrest";
            }
            else
            {
                LblDate.Content = "";
            }
        }

        private void Time_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Time.Text == "")
            {
                LblTime.Content = "Date Of Arrest";
            }
            else
            {
                LblTime.Content = "";
            }
        }
    }

}
