﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PNP
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private DataClasses1DataContext db_con = new DataClasses1DataContext(Properties.Settings.Default.PrisonDBConnectionString);
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Click_1(object sender, RoutedEventArgs e)
        {
            int count = db_con.Login(user.Text, pass.Text).Count();

            if(count > 0)
            {
                db_con.LogsInsert(user.Text, " has logged in to the application on ");

                foreach(var s in db_con.Perms(user.Text))
                {
                    Variables.perms = s.userPerms;
                }
                Variables.user = user.Text;
                MainWindow mw = new MainWindow();
                mw.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Username or Password is incorrect . . .");
                user.Text = "";
                pass.Text = "";
            }
        }
    }
}
