﻿using AForge.Video;
using AForge.Video.DirectShow;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using MessageBox = System.Windows.Forms.MessageBox;

namespace PNP
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public FilterInfoCollection fic = null;
        public VideoCaptureDevice vcd = null;
        public bool OnOff = false;
        private DataClasses1DataContext db_con = new DataClasses1DataContext(Properties.Settings.Default.PrisonDBConnectionString);
        public string Mstat = "";
        public char Msex = ' ';
        public string Marks = "";
        public string idid = "";
        public Window2()
        {
            InitializeComponent();
            fic = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo fi in fic)
                WbCams.Items.Add(fi.Name);
            WbCams.SelectedIndex = 0;
            vcd = new VideoCaptureDevice();
            Save_Pic.IsEnabled = false;
            if (Variables.FilePath == "")
            {
                System.Windows.MessageBox.Show("File path has not been set, go to the settings and set a location for data to be saved. Go Back To MainMenu to set it");
                Save_Pic.IsEnabled = false;
                Wbcam.IsEnabled = false;
            }
            int count = 0;
            foreach (var j in db_con.tbl_Bookings)
                count++;
            if (count > 0)
            {
                Blotter.Text = "BOOK" + count.ToString().PadLeft(3, '0');
            }
            else
            {
                Blotter.Text = "BOOK000";
            }

        }

        private void Wbcam_Click(object sender, RoutedEventArgs e)
        {
            if (OnOff == false)
            {
                Wbcam.Background = new SolidColorBrush(Colors.LightGreen);
                Wbcam.Content = "ON";
                vcd = new VideoCaptureDevice(fic[WbCams.SelectedIndex].MonikerString);
                vcd.NewFrame += Vcd_NewFrame;
                vcd.Start();
                OnOff = true;
                Save_Pic.IsEnabled = true;
            }
            else if (OnOff == true)
            {
                Wbcam.Background = new SolidColorBrush(Colors.Red);
                Wbcam.Content = "OFF";
                OnOff = false;
                Webcam.Source = null;
                Save_Pic.IsEnabled = false;
                vcd.SignalToStop();
            }

        }
        private void Vcd_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            this.Dispatcher.Invoke(() =>
            {
                Webcam.Source = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                        ((Bitmap)eventArgs.Frame.Clone()).GetHbitmap(),
                        IntPtr.Zero,
                        System.Windows.Int32Rect.Empty,
                        BitmapSizeOptions.FromWidthAndHeight((int)Webcam.Width, (int)Webcam.Height));
            });
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (vcd.IsRunning)
            {
                vcd.SignalToStop();
                vcd = null;
            }
        }

        public void ImageToFile(string filePath)
        {
            var image = Webcam.Source;
            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                BitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create((BitmapSource)image));
                encoder.Save(fileStream);
            }
        }

        private void Save_Pic_Click(object sender, RoutedEventArgs e)
        {
            Save_Pic.IsEnabled = false;
            Wbcam.Content = "RST";
            Wbcam.Background = new SolidColorBrush(Colors.Red);
            OnOff = false;
            ImageToFile(Variables.FilePath + "/" + Blotter.Text + ".png");
            vcd.SignalToStop();
        }


        //=========================================== FIRST TAB ==========================================================
        private void Blotter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Blotter.Text == "")
            {
                Blotterlbl.Content = "Blotter Entry Number";
            }
            else
            {
                Blotterlbl.Content = "";
            }
        }

        private void FN_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (FN.Text == "")
            {
                FNlbl.Content = "First Name";
            }
            else
            {
                FNlbl.Content = "";
            }
        }

        private void LN_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (LN.Text == "")
            {
                LNlbl.Content = "Last Name";
            }
            else
            {
                LNlbl.Content = "";
            }
        }

        private void MN_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (MN.Text == "")
            {
                MNlbl.Content = "Middle Name";
            }
            else
            {
                MNlbl.Content = "";
            }
        }

        private void Address_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Address.Text == "")
            {
                Addresslbl.Content = "Address";
            }
            else
            {
                Addresslbl.Content = "";
            }
        }

        private void Single_Checked(object sender, RoutedEventArgs e)
        {
            Married.IsChecked = false;
            Widower.IsChecked = false;
            Separated.IsChecked = false;
            Mstat = "Single";
            
        }

        private void Married_Checked(object sender, RoutedEventArgs e)
        {
            Single.IsChecked = false;
            Widower.IsChecked = false;
            Separated.IsChecked = false;

            Mstat = "Married";

        }

        private void Widower_Checked(object sender, RoutedEventArgs e)
        {
            Married.IsChecked = false;
            Single.IsChecked = false;
            Separated.IsChecked = false;

            Mstat = "Widowed";
        }

        private void Separated_Checked(object sender, RoutedEventArgs e)
        {
            Single.IsChecked = false;
            Married.IsChecked = false;
            Widower.IsChecked = false;

            Mstat = "Separated";
        }

        private void Male_Checked(object sender, RoutedEventArgs e)
        {
            Female.IsChecked = false;
            Msex = 'M';
        }

        private void Female_Checked(object sender, RoutedEventArgs e)
        {
            Male.IsChecked = false;
            Msex = 'F';
        }

        private void Nationality_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Nationality.Text == "")
            {
                Nationlbl.Content = "Nationality";
            }
            else
            {
                Nationlbl.Content = "";
            }
        }

        private void AKA_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (AKA.Text == "")
            {
                AKAlbl.Content = "Alias/es";
            }
            else
            {
                AKAlbl.Content = "";
            }
        }

        private void Contact_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Contact.Text == "")
            {
                Contactlbl.Content = "Tel No. / Contact No.";
            }
            else
            {
                Contactlbl.Content = "";
            }
        }

        private void MarksDesc_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (MarksDesc.Text == "")
            {
                Desclbl.Content = "Description of the Identifying Marks";
            }
            else
            {
                Desclbl.Content = "";
            }
        }

        private void Age_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Age.Text == "")
            {
                Agelbl.Content = "Age";
            }
            else
            {
                Agelbl.Content = "";
            }
        }

        private void Height_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Height.Text == "")
            {
                Heightlbl.Content = "Height";
            }
            else
            {
                Heightlbl.Content = "";
            }
        }

        private void Weight_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Weight.Text == "")
            {
                Weightlbl.Content = "Weight";
            }
            else
            {
                Weightlbl.Content = "";
            }
        }

        private void Hair_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Hair.Text == "")
            {
                Hairlbl.Content = "Hair Colour";
            }
            else
            {
                Hairlbl.Content = "";
            }
        }

        private void Eye_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Eye.Text == "")
            {
                Eyelbl.Content = "Eye Colour";
            }
            else
            {
                Eyelbl.Content = "";
            }
        }

        private void Skin_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Skin.Text == "")
            {
                Skinlbl.Content = "Skin Colour";
            }
            else
            {
                Skinlbl.Content = "";
            }
        }

        private void Occupation_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Occupation.Text == "")
            {
                Occupationlbl.Content = "Occupation";
            }
            else
            {
                Occupationlbl.Content = "";
            }
        }

        private void Ethnic_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Ethnic.Text == "")
            {
                Ethniclbl.Content = "Ethnicity";
            }
            else
            {
                Ethniclbl.Content = "";
            }
        }

        private void Dialect_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Dialect.Text == "")
            {
                Dialectlbl.Content = "Dialect";
            }
            else
            {
                Dialectlbl.Content = "";
            }
        }

        private void Defect_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Defect.Text == "")
            {
                Defectlbl.Content = "Description of Physical Deformities";
            }
            else
            {
                Defectlbl.Content = "";
            }
        }

        private void ID_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (ID.Text == "")
            {
                IDlbl.Content = "ID TYPE";
            }
            else
            {
                IDlbl.Content = "";
            }
        }

        private void IDNUM_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (IDNUM.Text == "")
            {
                IDNUMlbl.Content = "ID NUMBER";
            }
            else
            {
                IDNUMlbl.Content = "";
            }
        }

        //=========================================== SECOND TAB ==========================================================


        //=========================================== THIRD TAB ==========================================================


        //=========================================== FOURTH TAB ==========================================================

        private void MainMenu_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            if (FN.Equals("") || MN.Equals("") || LN.Equals("") || Address.Equals("") || Mstat.Equals("") || Msex.Equals("") || Nationality.Equals("") || Contact.Equals("") || Age.Equals("") || Height.Equals("") || Weight.Equals("") || Hair.Equals("") || Eye.Equals("") || 
                Skin.Equals("") || Occupation.Equals("") || Ethnic.Equals("") || Dialect.Equals("") || ID.Equals(""))
            {
                MessageBox.Show("Please complete filling up the form . . .");
            }
            else
            {
                
                if(Mole.IsChecked == true)
                {
                    Marks += ",Mole ";
                }
                if (Tattoo.IsChecked == true)
                {
                    Marks += ",Tattoo ";
                }
                if (Birthmark.IsChecked == true)
                {
                    Marks += ",Birthmark ";
                }
                if (Scar.IsChecked == true)
                {
                    Marks += ",Scar ";
                }
                db_con.bookInsert(Blotter.Text, DateTime.Today, LN.Text, MN.Text, FN.Text, AKA.Text, Address.Text, Contact.Text, Mstat, Msex, Convert.ToInt32(Age.Text), Convert.ToInt32(Weight.Text), Convert.ToInt32(Height.Text), Eye.Text, Hair.Text, Skin.Text, Occupation.Text, Nationality.Text,
                    Ethnic.Text, Dialect.Text, Marks, MarksDesc.Text, Defect.Text, ID.Text, IDNUM.Text, Variables.FilePath + @"\" + Blotter.Text + ".png", false, Variables.user);
                MessageBox.Show("things inserted");
                db_con.LogsInsert(Variables.user, " has booked ID number : " + Blotter.Text + " on ");

                new MainWindow().Show();
                this.Close();
            }
        }

        private void Fill_Click(object sender, RoutedEventArgs e)
        {
            FN.Text = "Glenn";
            LN.Text = "Somalilo";
            MN.Text = "Andrew";
            Address.Text = "Somewhere in Las pinas";
            Occupation.Text = "Student";
            Ethnic.Text = "Zamboangaperson";
            Dialect.Text = "Chavacano";
            Nationality.Text = "Filipino";
            Contact.Text = "213908123";
            Age.Text = "12";
            Height.Text = "123";
            Weight.Text = "123";
            Hair.Text = "Black";
            Eye.Text = "Brown";
            Skin.Text = "Brown";
            ID.Text = "National ID";
            IDNUM.Text = "12313123";
        }
    }
            
}
