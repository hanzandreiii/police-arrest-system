﻿using AForge.Video;
using AForge.Video.DirectShow;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PNP
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class View : Window
    {
        private DataClasses1DataContext db_con = new DataClasses1DataContext(Properties.Settings.Default.PrisonDBConnectionString);
        public string idid = "";
        private List<string> list = new List<string>();
        public View()
        {
            InitializeComponent();
            foreach (var s in db_con.tbl_Bookings)
            {
                if(s.bookStatus == true)
                list.Add(s.bookID.ToString().Trim() + " " + s.bookFN.ToString().Trim() + " " + s.bookLN.ToString().Trim());
            }
            names.ItemsSource = list;
        }


        private void MainMenu_Click(object sender, RoutedEventArgs e)
        {
            new MainWindow().Show();
            this.Close();
        }

        private void names_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int val = Convert.ToInt32(names.SelectedIndex);
            string choice = list.ElementAt(val);
            string firstWord = choice.Substring(0, choice.IndexOf(" "));
            idid = firstWord;
            dabox.Items.Clear();
            foreach(var s in db_con.BookView(firstWord))
            {
                Blotter.Text = s.bookID.ToString();
                FN.Text = s.bookFN;
                MN.Text = s.bookMN;
                LN.Text = s.bookLN;
                Webcam.Source = new BitmapImage(new Uri(s.bookPicture));
                Address.Text = s.bookAddress;
                Occupation.Text = s.bookOccupation;
                Ethnic.Text = s.bookEthnicity;
                Defect.Text = s.bookDefect;
                Dialect.Text = s.bookDialect;
                Nationality.Text = s.bookNationality;
                AKA.Text = s.bookAKA;
                Contact.Text = s.bookSusNo;
                MarksDesc.Text = s.bookMarkLoc;
                ID.Text = s.bookSusID;
                IDNUM.Text = s.bookSusIDNo;
                Age.Text = s.bookAge.ToString();
                Height.Text = s.bookHeight.ToString();
                Weight.Text = s.bookWeight.ToString();
                Eye.Text = s.bookEye.ToString();
                Hair.Text = s.bookHair.ToString();
                Skin.Text = s.bookSkin.ToString();
                sex.Content = "Sex at Birth : " + s.bookSex;
                Mstat.Content = "Marital Status : " + s.bookMStat;
                Marks.Content = "Identifying Marks :" + s.bookMarks;
            }

            foreach (var s in db_con.ArrestView(firstWord))
            {
                dabox.Items.Add(s.arrestCharge);
            }
        }

        private void dabox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string thing = dabox.SelectedItem.ToString();
            foreach (var s in db_con.ArrestView(idid))
            {
                if(s.arrestCharge == thing)
                {
                    Mod1.Text = s.arrestMO;
                    Arr1.Text = s.arrestOfficer;
                    Unit.Text = s.arrestUnit;
                    Date.Text = s.arrestTime.ToString();
                    Location.Text = s.arrestLoc;
                }
            }
        }
    }
}
