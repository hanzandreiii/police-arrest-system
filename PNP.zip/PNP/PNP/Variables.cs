﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PNP
{
    internal class Variables
    {
        public static string FilePath = "";
        public static string user = "";
        public static bool? perms = false;
    }
}
